/* $Id$ */
# include "cppad/speed_test.hpp"
