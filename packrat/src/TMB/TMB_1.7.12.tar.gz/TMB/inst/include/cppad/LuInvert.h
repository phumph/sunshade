/* $Id$ */
# include "cppad/lu_invert.hpp"
